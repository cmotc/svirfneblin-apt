# svirfneblin
Re-implementing gnome-panel(sorta) as an awesome config. Considered calling it
"mutterfixer." Also because while I'm not a systemd alarmist, I'm also not a
fan. More an OpenRC guy. Yes, I know. I also write in my votes for president
and bake my own bread. What can I say, I'm a man of principle.
